globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/0f519_next_dist_compiled_next-devtools_index_a70ee41f.js",
      "static/chunks/0f519_next_dist_compiled_37943f7e._.js",
      "static/chunks/0f519_next_dist_shared_lib_e4cffd1d._.js",
      "static/chunks/0f519_next_dist_client_acd02ac3._.js",
      "static/chunks/0f519_next_dist_1834b1b4._.js",
      "static/chunks/0f519_next_app_9ea39bcb.js",
      "static/chunks/[next]_entry_page-loader_ts_8e035b61._.js",
      "static/chunks/0f519_react-dom_00e4c33d._.js",
      "static/chunks/0f519_fefad838._.js",
      "static/chunks/[root-of-the-server]__a190f4ae._.js",
      "static/chunks/post_pages__app_2da965e7._.js",
      "static/chunks/turbopack-post_pages__app_4b07dab2._.js"
    ],
    "/_error": [
      "static/chunks/0f519_next_dist_compiled_next-devtools_index_a70ee41f.js",
      "static/chunks/0f519_next_dist_compiled_37943f7e._.js",
      "static/chunks/0f519_next_dist_shared_lib_02bd1415._.js",
      "static/chunks/0f519_next_dist_client_acd02ac3._.js",
      "static/chunks/0f519_next_dist_213a0aee._.js",
      "static/chunks/0f519_next_error_4b365340.js",
      "static/chunks/[next]_entry_page-loader_ts_76ab55fc._.js",
      "static/chunks/0f519_react-dom_00e4c33d._.js",
      "static/chunks/0f519_fefad838._.js",
      "static/chunks/[root-of-the-server]__89f80362._.js",
      "static/chunks/post_pages__error_2da965e7._.js",
      "static/chunks/turbopack-post_pages__error_907a0161._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/0f519_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_3f8b82dc._.js",
    "static/chunks/0f519_next_dist_compiled_react-dom_7db68401._.js",
    "static/chunks/0f519_next_dist_compiled_next-devtools_index_e4cf56e9.js",
    "static/chunks/0f519_next_dist_compiled_036fa53a._.js",
    "static/chunks/0f519_next_dist_client_7b19d762._.js",
    "static/chunks/0f519_next_dist_a3b41de3._.js",
    "static/chunks/0f519_@swc_helpers_cjs_9c326f2d._.js",
    "static/chunks/post_a0ff3932._.js",
    "static/chunks/turbopack-post_8c659ae8._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];