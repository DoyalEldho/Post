var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/posts/[id]/route.js")
R.c("server/chunks/0f519_next_dist_93229208._.js")
R.c("server/chunks/[root-of-the-server]__349e2a38._.js")
R.m("[project]/post/.next-internal/server/app/api/posts/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/post/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/post/src/app/api/posts/[id]/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/post/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/post/src/app/api/posts/[id]/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
