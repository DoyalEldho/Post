var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/0f519_next_20413c74._.js")
R.c("server/chunks/[root-of-the-server]__25f50687._.js")
R.m("[project]/post/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/post/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/post/src/app/favicon--route-entry.js [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)")
module.exports=R.m("[project]/post/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/post/src/app/favicon--route-entry.js [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)").exports
