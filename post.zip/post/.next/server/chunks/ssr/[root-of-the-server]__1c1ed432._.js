module.exports = [
"[project]/post/.next-internal/server/app/api/posts/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/post/src/app/favicon.ico.mjs { IMAGE => \"[project]/post/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/post/src/app/favicon.ico.mjs { IMAGE => \"[project]/post/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/post/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/post/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[externals]/mongoose [external] (mongoose, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mongoose", () => require("mongoose"));

module.exports = mod;
}),
"[project]/post/src/app/Model/Post.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const PostSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].Schema({
    title: {
        type: String,
        required: true
    },
    content: {
        type: String,
        required: true
    },
    tags: {
        type: [
            String
        ]
    }
}, {
    timestamps: true
});
const Post = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].models.Post || __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].model("Post", PostSchema);
const __TURBOPACK__default__export__ = Post;
}),
"[project]/post/src/app/dbConfig/dbConfig.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "connectDB",
    ()=>connectDB
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
async function connectDB(params) {
    try {
        __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].connect(process.env.MONGO_URL);
        const dbConnection = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].connection;
        dbConnection.on('connected', ()=>{
            console.log('mongodb connected sucessfully');
        });
        dbConnection.on('error', (e)=>{
            console.log('mongodb errror', e);
        });
    } catch (error) {
        console.log('something went wrong');
        console.log(error);
    }
}
}),
"[project]/post/src/app/api/posts/page.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$post$2f$src$2f$app$2f$Model$2f$Post$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/post/src/app/Model/Post.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$post$2f$src$2f$app$2f$dbConfig$2f$dbConfig$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/post/src/app/dbConfig/dbConfig.js [app-rsc] (ecmascript)");
;
;
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$post$2f$src$2f$app$2f$dbConfig$2f$dbConfig$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["connectDB"])();
async function POST(req) {
    try {
        const { title, content, tags } = await req.json();
        const post = await __TURBOPACK__imported__module__$5b$project$5d2f$post$2f$src$2f$app$2f$Model$2f$Post$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].create({
            title,
            content,
            tags
        });
        return new Response(JSON.stringify(post), {
            status: 201
        });
    } catch (err) {
        return new Response(JSON.stringify({
            error: err.message
        }), {
            status: 500
        });
    }
}
async function GET(req) {
    try {
        const posts = await __TURBOPACK__imported__module__$5b$project$5d2f$post$2f$src$2f$app$2f$Model$2f$Post$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].find();
        return new Response(JSON.stringify(posts), {
            status: 200
        });
    } catch (err) {
        return new Response(JSON.stringify({
            error: err.message
        }), {
            status: 500
        });
    }
}
}),
"[project]/post/src/app/api/posts/page.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/post/src/app/api/posts/page.js [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__1c1ed432._.js.map