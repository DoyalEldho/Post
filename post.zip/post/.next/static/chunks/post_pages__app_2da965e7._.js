(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/0f519_next_dist_compiled_next-devtools_index_a70ee41f.js",
  "static/chunks/0f519_next_dist_compiled_37943f7e._.js",
  "static/chunks/0f519_next_dist_shared_lib_e4cffd1d._.js",
  "static/chunks/0f519_next_dist_client_acd02ac3._.js",
  "static/chunks/0f519_next_dist_1834b1b4._.js",
  "static/chunks/0f519_next_app_9ea39bcb.js",
  "static/chunks/[next]_entry_page-loader_ts_8e035b61._.js",
  "static/chunks/0f519_react-dom_00e4c33d._.js",
  "static/chunks/0f519_fefad838._.js",
  "static/chunks/[root-of-the-server]__a190f4ae._.js"
],
    source: "entry"
});
