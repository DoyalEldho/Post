(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_3f8b82dc._.js",
  "static/chunks/0f519_next_dist_compiled_react-dom_7db68401._.js",
  "static/chunks/0f519_next_dist_compiled_next-devtools_index_e4cf56e9.js",
  "static/chunks/0f519_next_dist_compiled_036fa53a._.js",
  "static/chunks/0f519_next_dist_client_7b19d762._.js",
  "static/chunks/0f519_next_dist_a3b41de3._.js",
  "static/chunks/0f519_@swc_helpers_cjs_9c326f2d._.js"
],
    source: "entry"
});
