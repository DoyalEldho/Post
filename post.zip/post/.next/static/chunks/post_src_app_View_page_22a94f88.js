(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_adbad3b7._.js",
  "static/chunks/post_src_app_View_page_97b11dff.js"
],
    source: "dynamic"
});
