__turbopack_load_page_chunks__("/_error", [
  "static/chunks/0f519_next_dist_compiled_next-devtools_index_a70ee41f.js",
  "static/chunks/0f519_next_dist_compiled_37943f7e._.js",
  "static/chunks/0f519_next_dist_shared_lib_02bd1415._.js",
  "static/chunks/0f519_next_dist_client_acd02ac3._.js",
  "static/chunks/0f519_next_dist_213a0aee._.js",
  "static/chunks/0f519_next_error_4b365340.js",
  "static/chunks/[next]_entry_page-loader_ts_76ab55fc._.js",
  "static/chunks/0f519_react-dom_00e4c33d._.js",
  "static/chunks/0f519_fefad838._.js",
  "static/chunks/[root-of-the-server]__89f80362._.js",
  "static/chunks/post_pages__error_2da965e7._.js",
  "static/chunks/turbopack-post_pages__error_907a0161._.js"
])
